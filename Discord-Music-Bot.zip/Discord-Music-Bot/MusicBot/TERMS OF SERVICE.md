Terms of use:

Please read the following terms of use carefully. By using the Discord bot named MusicMaker, you agree to the following terms.

Terms of Service:
a. The MusicMaker bot is designed to improve the music listening experience on Discord servers. You can take advantage of all the features of the bot.
b. When using the MusicMaker bot, you must comply with Discord's terms of service and rules. Abuse or misuse of the bot outside its intended purpose may lead to account closure.
c. The MusicMaker bot is free to use. However, you may need to have certain permissions for the use of some features.
d. The MusicMaker bot can be constantly updated and add new features. You are deemed to have accepted these updates automatically.

privacy policy:
a. The MusicMaker bot does not record the transactions and data that you perform on Discord servers.
b. The MusicMaker bot may need to access some basic server information in order to work. However, this information is not shared with third parties or misused in any way.
c. The MusicMaker bot does not collect or use user data for advertising or marketing purposes.

Disclaimer of Liability:
a. OpenAI or the developer of the bot are not responsible for any problems or damages caused by the use of the MusicMaker bot.
b. In case of incorrect operation of the MusicMaker bot or if there are interruptions, no responsibility is accepted for any problems or damages caused by this situation.
c. The user is responsible for problems caused by incorrect or incorrect use of the MusicMaker bot.

Intellectual Property Rights:
a. All intellectual property rights of MusicMaker bot belong to OPENAI. It is forbidden to use any part, source code or content of the bot without permission.

Changes:
a. We reserve the right to change the terms of use and privacy policy of MusicMaker bot at any time. When changes are made, the updated terms and policies take effect immediately. For this reason, it is recommended that you check this page regularly.

Communication:
a. If you have any questions, suggestions or complaints about the MusicMaker bot, please contact the developer of the bot.

These terms of use regulate the use of the MusicMaker bot. By using the MusicMaker bot, you agree to the above terms.